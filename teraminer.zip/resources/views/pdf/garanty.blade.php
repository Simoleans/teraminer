<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <title>Teraminer</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>
  <header class="encabezado">
    <h1 class="titulo">Teraminer</h1>
    <span class="subtitulo">Certificado de Garantía ACIS | WhatsminerAcis Miner</span>
  </header>
</body>
</html>
