<template>
    <img src="/img/teraminer.png" alt="">
</template>
