<template>
    <div class="flex flex-col justify-end items-end">
        <span class="font-bold text-2xl">TERAMINER</span>
        <span>CERTIFICADO DE GARANTIA ACIS </span>
        <span>WhatsminerAcis Miner </span>
    </div>
</template>
